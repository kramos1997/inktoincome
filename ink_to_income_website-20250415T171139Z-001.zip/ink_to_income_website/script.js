// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const nav = document.querySelector('nav');
    
    if (mobileMenuToggle && nav) {
        mobileMenuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            mobileMenuToggle.classList.toggle('active');
        });
    }
    
    // Form submission handling
    const workshopForm = document.getElementById('workshop-signup-form');
    if (workshopForm) {
        workshopForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you for signing up for our workshop! We\'ll send you the details shortly.');
            workshopForm.reset();
        });
    }
    
    const discoveryForm = document.getElementById('discovery-call-form');
    if (discoveryForm) {
        discoveryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you for requesting a discovery call! We\'ll contact you within 24 hours to schedule your call.');
            discoveryForm.reset();
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add active class to current page in navigation
    const currentPage = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('nav ul li a');
    
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage || (currentPage === '' && linkHref === 'index.html')) {
            link.classList.add('active');
        }
    });
});

// Add CSS class for mobile menu when active
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.textContent = `
        @media (max-width: 768px) {
            nav.active {
                display: block;
                position: absolute;
                top: 80px;
                left: 0;
                width: 100%;
                background-color: var(--white);
                box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
                z-index: 1000;
            }
            
            nav.active ul {
                flex-direction: column;
                padding: 20px;
            }
            
            nav.active ul li {
                margin: 10px 0;
            }
            
            .mobile-menu-toggle.active span:nth-child(1) {
                transform: rotate(45deg) translate(5px, 5px);
            }
            
            .mobile-menu-toggle.active span:nth-child(2) {
                opacity: 0;
            }
            
            .mobile-menu-toggle.active span:nth-child(3) {
                transform: rotate(-45deg) translate(5px, -5px);
            }
        }
        
        nav ul li a.active {
            color: var(--accent-color);
            font-weight: bold;
        }
    `;
    document.head.appendChild(style);
});

// Lead magnet popup
document.addEventListener('DOMContentLoaded', function() {
    // Create popup elements
    const popupOverlay = document.createElement('div');
    popupOverlay.className = 'popup-overlay';
    
    const popupContent = document.createElement('div');
    popupContent.className = 'popup-content';
    
    const closeButton = document.createElement('button');
    closeButton.className = 'popup-close';
    closeButton.innerHTML = '&times;';
    
    popupContent.innerHTML = `
        <h3>Get Your Free Guide</h3>
        <p>10 Ethical AI Prompts for Faith-Driven Writers</p>
        <form id="lead-magnet-form">
            <div class="form-group">
                <label for="popup-name">Your Name</label>
                <input type="text" id="popup-name" name="name" required>
            </div>
            <div class="form-group">
                <label for="popup-email">Email Address</label>
                <input type="email" id="popup-email" name="email" required>
            </div>
            <button type="submit" class="btn-primary">Send Me the Guide</button>
        </form>
    `;
    
    popupContent.appendChild(closeButton);
    popupOverlay.appendChild(popupContent);
    document.body.appendChild(popupOverlay);
    
    // Add styles for popup
    const popupStyles = document.createElement('style');
    popupStyles.textContent = `
        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .popup-content {
            background-color: var(--white);
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            position: relative;
        }
        
        .popup-close {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            background: none;
            border: none;
            cursor: pointer;
        }
        
        .popup-content h3 {
            margin-bottom: 10px;
        }
        
        .popup-content p {
            margin-bottom: 20px;
        }
        
        #lead-magnet-form .btn-primary {
            width: 100%;
            margin-top: 10px;
        }
    `;
    document.head.appendChild(popupStyles);
    
    // Show popup after 30 seconds or when user is about to leave
    let popupShown = false;
    
    // Show after delay
    setTimeout(function() {
        if (!popupShown && !sessionStorage.getItem('popupShown')) {
            popupOverlay.style.display = 'flex';
            popupShown = true;
        }
    }, 30000);
    
    // Show on exit intent
    document.addEventListener('mouseleave', function(e) {
        if (e.clientY < 0 && !popupShown && !sessionStorage.getItem('popupShown')) {
            popupOverlay.style.display = 'flex';
            popupShown = true;
        }
    });
    
    // Close popup
    closeButton.addEventListener('click', function() {
        popupOverlay.style.display = 'none';
        sessionStorage.setItem('popupShown', 'true');
    });
    
    // Handle form submission
    const leadMagnetForm = document.getElementById('lead-magnet-form');
    leadMagnetForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you! Your free guide is on its way to your inbox.');
        popupOverlay.style.display = 'none';
        sessionStorage.setItem('popupShown', 'true');
        leadMagnetForm.reset();
    });
});

// Add CSS for program page specific styles
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('program.html')) {
        const programStyles = document.createElement('style');
        programStyles.textContent = `
            .page-header {
                background-color: var(--primary-color);
                color: var(--white);
                text-align: center;
                padding: 120px 0 60px;
            }
            
            .page-header h1 {
                margin-bottom: 10px;
            }
            
            .program-intro {
                background-color: var(--white);
            }
            
            .program-intro .container {
                display: flex;
                align-items: center;
                gap: 50px;
            }
            
            .program-intro-content {
                flex: 1;
            }
            
            .program-intro-image {
                flex: 1;
            }
            
            .program-intro-image img {
                max-width: 100%;
                border-radius: 10px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            }
            
            .program-intro-features {
                margin-top: 30px;
            }
            
            .intro-feature {
                display: flex;
                align-items: flex-start;
                margin-bottom: 20px;
            }
            
            .intro-feature-icon {
                font-size: 1.5rem;
                color: var(--accent-color);
                margin-right: 15px;
                min-width: 30px;
            }
            
            .program-tiers-section {
                background-color: var(--light-color);
            }
            
            .section-intro {
                text-align: center;
                max-width: 800px;
                margin: 0 auto 40px;
            }
            
            .tiers-container {
                display: flex;
                flex-wrap: wrap;
                gap: 30px;
                justify-content: center;
            }
            
            .tier-card {
                flex: 1;
                min-width: 300px;
                max-width: 350px;
            }
            
            .tier-limited {
                font-size: 0.9rem;
                background-color: var(--secondary-color);
                color: var(--dark-color);
                padding: 5px 10px;
                border-radius: 20px;
                display: inline-block;
                margin-top: 10px;
            }
            
            .tier-ideal {
                font-style: italic;
                margin-top: 20px;
                font-size: 0.9rem;
            }
            
            .payment-options {
                text-align: center;
                margin-top: 40px;
                padding: 20px;
                background-color: var(--white);
                border-radius: 10px;
            }
            
            .program-components {
                background-color: var(--white);
            }
            
            .component-category {
                margin-bottom: 50px;
            }
            
            .component-category h3 {
                margin-bottom: 30px;
                text-align: center;
            }
            
            .components-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
            
            .component-card {
                background-color: var(--gray);
                padding: 20px;
                border-radius: 10px;
                text-align: center;
            }
            
            .component-icon {
                font-size: 2rem;
                color: var(--primary-color);
                margin-bottom: 15px;
            }
            
            .program-process {
                background-color: var(--light-color);
            }
            
            .process-steps {
                max-width: 800px;
                margin: 0 auto;
            }
            
            .process-step {
                display: flex;
                margin-bottom: 30px;
                position: relative;
            }
            
            .process-step:not(:last-child):after {
                content: '';
                position: absolute;
                top: 50px;
                left: 25px;
                height: calc(100% - 20px);
                width: 2px;
                background-color: var(--primary-color);
            }
            
            .step-number {
                width: 50px;
                height: 50px;
                background-color: var(--primary-color);
                color: var(--white);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
                font-size: 1.2rem;
                margin-right: 20px;
                z-index: 1;
            }
            
            .step-content {
                flex: 1;
            }
            
            .faq {
                background-color: var(--white);
            }
            
            .faq-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 30px;
            }
            
            .faq-item h3 {
                margin-bottom: 10px;
                color: var(--primary-color);
            }
            
            .cta {
                background-color: var(--primary-color);
                color: var(--white);
                text-align: center;
                padding: 60px 0;
            }
            
            .cta h2 {
                margin-bottom: 20px;
            }
            
            .cta h2:after {
                left: 50%;
                transform: translateX(-50%);
                background-color: var(--secondary-color);
            }
            
            .contact-form {
                max-width: 800px;
                margin: 40px auto 0;
                background-color: var(--gray);
                padding: 30px;
                border-radius: 10px;
            }
            
            .form-row {
                display: flex;
                gap: 20px;
                margin-bottom: 20px;
            }
            
            .form-row .form-group {
                flex: 1;
            }
            
            textarea {
                width: 100%;
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-family: var(--font-body);
                resize: vertical;
            }
            
            @media (max-width: 992px) {
                .program-intro .container {
                    flex-direction: column;
                }
                
                .form-row {
                    flex-direction: column;
                    gap: 0;
                }
            }
        `;
        document.head.appendChild(programStyles);
    }
});
